from http.client import HTTPException


pip install httpx